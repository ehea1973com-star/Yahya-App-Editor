package com.yahya.appeditor

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Black = Color(0xFF101010)
private val Panel = Color(0xFF1C1C1C)
private val Gold = Color(0xFFD6AE4F)
private val SoftWhite = Color(0xFFF5F1E7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(16, 16, 16)
        window.navigationBarColor = android.graphics.Color.rgb(16, 16, 16)
        setContent { YahyaApp() }
    }
}

private data class Translation(val source: String, val translated: String)

@Composable
private fun YahyaApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("yahya_translations", ComponentActivity.MODE_PRIVATE) }
    val translations = remember { mutableStateListOf<Translation>().apply { addAll(loadTranslations(prefs.getString("items", "[]") ?: "[]")) } }
    var page by remember { mutableStateOf("home") }
    var sourceText by remember { mutableStateOf("") }
    var translatedText by remember { mutableStateOf("") }
    var editingIndex by remember { mutableIntStateOf(-1) }
    var apkName by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    fun saveItems() {
        val array = JSONArray()
        translations.forEach { item ->
            array.put(JSONObject().put("source", item.source).put("translated", item.translated))
        }
        prefs.edit().putString("items", array.toString()).apply()
    }

    val apkPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            apkName = uri.lastPathSegment?.substringAfterLast('/') ?: "تم اختيار ملف APK"
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            message = "تم اختيار الملف. لم يتم تعديل APK أو إعادة بنائه بعد."
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, onPrimary = Black, background = Black, surface = Panel,
        onBackground = SoftWhite, onSurface = SoftWhite, secondary = Gold
    )) {
        Column(Modifier.fillMaxSize().background(Black)) {
            Row(
                Modifier.fillMaxWidth().background(Panel).padding(horizontal = 18.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("يحيى", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black)
                Text("لتعديل التطبيقات", color = SoftWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }
            when (page) {
                "home" -> HomePage(
                    apkName = apkName,
                    onEditor = { page = "editor" },
                    onPicker = { apkPicker.launch(arrayOf("application/vnd.android.package-archive", "application/octet-stream")) },
                    onLinks = { page = "links" },
                    onSaved = { page = "saved" }
                )
                "editor" -> EditorPage(
                    source = sourceText, translated = translatedText,
                    onSource = { sourceText = it }, onTranslated = { translatedText = it },
                    onBack = { page = "home" },
                    onSave = {
                        if (sourceText.isBlank() || translatedText.isBlank()) {
                            message = "اكتب النص الأصلي والترجمة أولًا"
                        } else {
                            if (editingIndex in translations.indices) translations[editingIndex] = Translation(sourceText.trim(), translatedText.trim())
                            else translations.add(0, Translation(sourceText.trim(), translatedText.trim()))
                            saveItems(); sourceText = ""; translatedText = ""; editingIndex = -1
                            message = "تم حفظ الترجمة على الهاتف"
                        }
                    }, message = message,
                    onClearMessage = { message = "" }
                )
                "saved" -> SavedPage(
                    items = translations,
                    onBack = { page = "home" },
                    onEdit = { index, item -> editingIndex = index; sourceText = item.source; translatedText = item.translated; page = "editor" },
                    onDelete = { index -> translations.removeAt(index); saveItems() }
                )
                else -> LinksPage(onBack = { page = "home" })
            }
            Spacer(Modifier.weight(1f))
            Row(Modifier.fillMaxWidth().background(Panel).padding(8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                NavItem("الرئيسية", page == "home") { page = "home" }
                NavItem("المترجم", page == "editor") { page = "editor" }
                NavItem("المحفوظات", page == "saved") { page = "saved" }
                NavItem("روابطنا", page == "links") { page = "links" }
            }
        }
    }
}

@Composable
private fun HomePage(apkName: String, onEditor: () -> Unit, onPicker: () -> Unit, onLinks: () -> Unit, onSaved: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(18.dp))
        Text("مرحبًا بك في", color = SoftWhite, fontSize = 19.sp)
        Text("يحيى لتعديل التطبيقات", color = Gold, fontSize = 27.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
        Text("ترجمة يدوية • حفظ محلي • أدوات APK", color = Color.LightGray, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 10.dp, bottom = 24.dp))
        FeatureCard("اختيار ملف APK", "حدد ملف تطبيق من ذاكرة هاتفك", "📦", onPicker)
        if (apkName.isNotBlank()) Text("الملف المحدد: $apkName", color = Gold, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        FeatureCard("محرر الترجمة", "أضف النص الأصلي والترجمة العربية", "✍️", onEditor)
        FeatureCard("الترجمات المحفوظة", "راجع ترجماتك وعدّلها أو احذفها", "🗂️", onSaved)
        FeatureCard("قنوات التواصل", "تلغرام ويوتيوب وفيسبوك", "🔗", onLinks)
        Text("ملاحظة: اختيار APK متاح، أما إعادة بناء التطبيق وتوقيعه فتحتاج إلى أداة بناء APK متوافقة.", color = Color.Gray, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 10.dp))
    }
}

@Composable
private fun FeatureCard(title: String, subtitle: String, emoji: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Panel, RoundedCornerShape(16.dp)).clickable { onClick() }.padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(emoji, fontSize = 25.sp, modifier = Modifier.padding(end = 14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Gold, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(subtitle, color = SoftWhite.copy(alpha = .75f), fontSize = 12.sp)
        }
        Text("‹", color = Gold, fontSize = 28.sp)
    }
}

@Composable
private fun EditorPage(source: String, translated: String, onSource: (String) -> Unit, onTranslated: (String) -> Unit, onBack: () -> Unit, onSave: () -> Unit, message: String, onClearMessage: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("محرر الترجمة", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
        Text("اكتب النص كما يظهر في التطبيق ثم أدخل ترجمته.", color = Color.LightGray, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp, bottom = 16.dp))
        OutlinedTextField(value = source, onValueChange = onSource, modifier = Modifier.fillMaxWidth(), label = { Text("النص الأصلي") }, minLines = 3, colors = fieldColors())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = translated, onValueChange = onTranslated, modifier = Modifier.fillMaxWidth(), label = { Text("الترجمة العربية") }, minLines = 3, colors = fieldColors())
        Spacer(Modifier.height(16.dp))
        GoldButton("حفظ الترجمة على الهاتف", onSave)
        if (message.isNotBlank()) Text(message, color = Gold, fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp).clickable { onClearMessage() })
        Spacer(Modifier.height(10.dp))
        Text("يُحفظ النص محليًا على هذا الجهاز، ولا يحتاج إلى اتصال بالإنترنت.", color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.weight(1f))
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)) { Text("العودة للرئيسية") }
    }
}

@Composable
private fun SavedPage(items: SnapshotStateList<Translation>, onBack: () -> Unit, onEdit: (Int, Translation) -> Unit, onDelete: (Int) -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("الترجمات المحفوظة", color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Black)
        if (items.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("لا توجد ترجمات محفوظة بعد", color = Color.LightGray) }
        } else {
            LazyColumn(Modifier.weight(1f).padding(top = 12.dp)) {
                itemsIndexed(items) { index, item ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).background(Panel, RoundedCornerShape(14.dp)).padding(14.dp)) {
                        Text("الأصل: ${item.source}", color = SoftWhite, fontWeight = FontWeight.Bold)
                        Text("الترجمة: ${item.translated}", color = Gold, modifier = Modifier.padding(top = 5.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = { onEdit(index, item) }) { Text("تعديل", color = Gold) }
                            TextButton(onClick = { onDelete(index) }) { Text("حذف", color = Color(0xFFFF7777)) }
                        }
                    }
                }
            }
        }
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)) { Text("العودة للرئيسية") }
    }
}

@Composable
private fun LinksPage(onBack: () -> Unit) {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("روابط التواصل", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
        Text("استبدل الروابط التجريبية بروابط قنواتك الرسمية عند تجهيزها.", color = Color.LightGray, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp, bottom = 18.dp))
        SocialButton("تلغرام", "https://t.me/", context)
        SocialButton("يوتيوب", "https://www.youtube.com/", context)
        SocialButton("فيسبوك", "https://www.facebook.com/", context)
        Spacer(Modifier.weight(1f))
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)) { Text("العودة للرئيسية") }
    }
}

@Composable
private fun SocialButton(label: String, url: String, context: android.content.Context) {
    Button(onClick = {
        try { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { }
    }, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), colors = ButtonDefaults.buttonColors(containerColor = Panel, contentColor = Gold)) {
        Text("فتح $label", fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun NavItem(label: String, selected: Boolean, onClick: () -> Unit) {
    Column(Modifier.clickable { onClick() }.padding(horizontal = 7.dp, vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = if (selected) Gold else Color.LightGray, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal, fontSize = 12.sp)
        if (selected) Spacer(Modifier.height(3.dp).width(22.dp).background(Gold, RoundedCornerShape(2.dp)))
    }
}

@Composable
private fun GoldButton(label: String, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black), shape = RoundedCornerShape(12.dp)) {
        Text(label, fontWeight = FontWeight.Black, modifier = Modifier.padding(vertical = 4.dp))
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Gold, unfocusedBorderColor = Color.Gray,
    focusedLabelColor = Gold, cursorColor = Gold,
    focusedTextColor = SoftWhite, unfocusedTextColor = SoftWhite,
    focusedContainerColor = Panel, unfocusedContainerColor = Panel
)

private fun loadTranslations(json: String): List<Translation> {
    return try {
        val array = JSONArray(json)
        (0 until array.length()).mapNotNull { index ->
            val obj = array.optJSONObject(index) ?: return@mapNotNull null
            Translation(obj.optString("source"), obj.optString("translated"))
        }
    } catch (_: Exception) { emptyList() }
}
